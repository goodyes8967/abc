/*
 * Copyright (c) 2020 The ZMK Contributors
 *
 * SPDX-License-Identifier: MIT
 */

#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>

LOG_MODULE_DECLARE(zmk, CONFIG_ZMK_LOG_LEVEL);

#include <zmk/event_manager.h>

extern struct zmk_event_type *__event_type_start[];
extern struct zmk_event_type *__event_type_end[];

extern char __zmk_events_rom_start[];

extern struct zmk_event_subscription __event_subscriptions_start[];
extern struct zmk_event_subscription __event_subscriptions_end[];

int zmk_event_manager_handle_from(zmk_event_t *event, uint8_t start_index) {
    static uint8_t inited = 0;
    if (!inited) {
        inited = 1;
        // LOG_ERR("zmk_events:%p,start:%p,end:%p,size:%d",__zmk_events_rom_start,__event_type_start,__event_subscriptions_end,(uint32_t)__event_subscriptions_end
        // - (uint32_t)__event_type_start);
        memcpy(__event_type_start, __zmk_events_rom_start,
               (uint32_t)__event_subscriptions_end - (uint32_t)__event_type_start);
    }
    int ret = 0;
    uint8_t len = __event_subscriptions_end - __event_subscriptions_start;
    // LOG_DBG("start index:%d,event len:%d",start_index,len);

    for (int i = start_index; i < len; i++) {

        struct zmk_event_subscription *ev_sub = __event_subscriptions_start + i;
        // LOG_HEXDUMP_DBG(ev_sub,sizeof(struct zmk_event_subscription),"sub");
        // LOG_DBG("sub event:%p,%p",ev_sub->event_type,event->event);
        if (ev_sub->event_type != event->event) {
            continue;
        }
        event->last_listener_index = i;
        // LOG_WRN("listener,index:%d,p:%p",i,ev_sub->listener);
        ret = ev_sub->listener->callback(event);
        switch (ret) {
        case ZMK_EV_EVENT_BUBBLE:
            continue;
        case ZMK_EV_EVENT_HANDLED:
            LOG_DBG("Listener handled the event");
            return 0;
        case ZMK_EV_EVENT_CAPTURED:
            LOG_DBG("Listener captured the event");
            return 0;
        default:
            LOG_DBG("Listener returned an error: %d", ret);
            return ret;
        }
    }

    return 0;
}

int zmk_event_manager_raise(zmk_event_t *event) { return zmk_event_manager_handle_from(event, 0); }

int zmk_event_manager_raise_after(zmk_event_t *event, const struct zmk_listener *listener) {
    uint8_t len = __event_subscriptions_end - __event_subscriptions_start;
    for (int i = 0; i < len; i++) {
        struct zmk_event_subscription *ev_sub = __event_subscriptions_start + i;

        if (ev_sub->event_type == event->event && ev_sub->listener == listener) {
            return zmk_event_manager_handle_from(event, i + 1);
        }
    }

    LOG_WRN("Unable to find where to raise this after event");

    return -EINVAL;
}

int zmk_event_manager_raise_at(zmk_event_t *event, const struct zmk_listener *listener) {
    uint8_t len = __event_subscriptions_end - __event_subscriptions_start;
    for (int i = 0; i < len; i++) {
        struct zmk_event_subscription *ev_sub = __event_subscriptions_start + i;

        if (ev_sub->event_type == event->event && ev_sub->listener == listener) {
            return zmk_event_manager_handle_from(event, i);
        }
    }

    LOG_WRN("Unable to find where to raise this event");

    return -EINVAL;
}

int zmk_event_manager_release(zmk_event_t *event) {
    return zmk_event_manager_handle_from(event, event->last_listener_index + 1);
}
