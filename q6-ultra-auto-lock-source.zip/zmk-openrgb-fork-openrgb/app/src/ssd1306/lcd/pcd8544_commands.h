/*
    MIT License

    Copyright (c) 2017-2018, Alexey Dynda

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
*/
/**
 * @file pcd8544_commands.h PCD8544 commands definitions
 */

#ifndef _PCD8544_COMMANDS_H_
#define _PCD8544_COMMANDS_H_

#ifdef __cplusplus
extern "C" {
#endif

/** PCD8544 LCD driver commands */
enum ESsd1306Commands {
    PCD8544_NOP = 0x00,

    // Regular functions
    PCD8544_FUNCTIONSET = 0x20,
    PCD8544_DISPLAYCONTROL = 0x08,
    PCD8544_SETYADDR = 0x40,
    PCD8544_SETXADDR = 0x80,

    // Extended functions
    PCD8544_SETTEMP = 0x04,
    PCD8544_SETBIAS = 0x10,
    PCD8544_SETVOP = 0x80,

};

/** PCD8544 supported function modes. */
enum EPcd8544FunctionMode {
    PCD8544_POWERDOWN = 0x04,
    PCD8544_VERTICAL_ADDR_MODE = 0x02,
    PCD8544_EXTENDEDINSTRUCTION = 0x01,
};

/** PCD8544 supported display modes. */
enum EPcd8544DisplayMode {
    PCD8544_DISPLAYBLANK = 0x0,
    PCD8544_DISPLAYALLON = 0x1,
    PCD8544_DISPLAYNORMAL = 0x4,
    PCD8544_DISPLAYINVERTED = 0x5,
};

#ifdef __cplusplus
}
#endif

// ----------------------------------------------------------------------------
#endif // _PCD8544_COMMANDS_H_
