#pragma once
#include "rgb_matrix_types.h"

#define __ NO_LED

#define ENCODER_SKIP_MASK
static const uint32_t encoder_skip_mask[MATRIX_ROWS] = {
    [0] = (1u << 18),
};

led_config_t g_led_config = {
    {// Key Matrix to LED Index
     {
         0, __, 1, 2, 3, 4, __, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, __,
     },
     {
         16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, __, 30, 31, 32, 33,
     },
     {
         34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, __, 48, 49, 50, __,
     },
     {
         51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, __, __, 64, 65, 66, 67,
     },
     {
         68, __, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, __, 80, 81, 82, 83, 84,
     },
     {
         85, 86, 87, __, __, __, 88, __, __, __, 89, 90, 91, 92, 93, 94, 95, 96, __,
     }},
    {
        // LED Index to Physical Position
        {0, 0},    {26, 0},   {39, 0},   {52, 0},   {65, 0},   {85, 0},   {98, 0},
        {111, 0},  {124, 0},  {143, 0},  {158, 0},  {171, 0},  {184, 0},  {196, 0},
        {208, 0},  {228, 0}, //{252,0}
        {0, 15},   {13, 15},  {26, 15},  {39, 15},  {52, 15},  {65, 15},  {78, 15},
        {91, 15},  {104, 15}, {117, 15}, {130, 15}, {143, 15}, {158, 15}, {179, 15},
        {197, 15}, {210, 15}, {230, 15}, {240, 15}, {1, 26},   {14, 26},  {27, 26},
        {40, 26},  {53, 26},  {66, 26},  {79, 26},  {94, 26},  {105, 26}, {118, 26},
        {131, 26}, {144, 26}, {159, 26}, {179, 26}, {197, 26}, {210, 26}, {230, 26},
        {2, 38},   {15, 38},  {28, 38},  {41, 38},  {54, 38},  {67, 38},  {80, 38},
        {94, 38},  {106, 38}, {119, 38}, {132, 38}, {150, 38}, {176, 38}, {197, 38},
        {210, 38}, {230, 38}, {240, 32}, {3, 49},   {26, 49},  {39, 49},  {52, 49},
        {65, 49},  {78, 49},  {91, 49},  {104, 49}, {117, 49}, {130, 49}, {143, 49},
        {164, 49}, {185, 52}, {197, 49}, {210, 49}, {230, 49}, {240, 55}, {0, 61},
        {13, 61},  {27, 61},  {79, 61},  {128, 61}, {143, 61}, {158, 61}, {171, 64},
        {185, 64}, {197, 61}, {210, 61}, {230, 61},
    },
    {// RGB LED Index to Flag
     1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 4, 4, 4, 4, 4, 4, 4,
     4, 4, 4, 4, 1, 1, 1, 1, 1, 1, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 1, 1,
     1, 8, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 1, 1, 1, 1, 1, 4, 4, 4, 4, 4, 4,
     4, 4, 4, 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4, 1, 1, 1, 1, 1, 1, 1, 1}};
#ifdef CONFIG_KEYCHRON_RGB_ENABLE
// Default Color of Per Key RGB
#define DC_RED                                                                                     \
    { 0, 255, 255 }
#define DC_BLU                                                                                     \
    { 170, 255, 255 }
#define DC_YLW                                                                                     \
    { 43, 255, 255 }

HSV default_per_key_led[RGB_MATRIX_LED_COUNT] = {
    DC_RED, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW,
    DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU,
    DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_YLW, DC_YLW, DC_YLW, DC_YLW,
    DC_YLW, DC_YLW, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU,
    DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_BLU, DC_BLU, DC_BLU,
    DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_RED, DC_YLW, DC_YLW,
    DC_YLW, DC_YLW, DC_YLW, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU, DC_BLU,
    DC_BLU, DC_BLU, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_RED, DC_YLW, DC_YLW, DC_YLW,
    DC_BLU, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW, DC_YLW};

// Default mixed RGB region
uint8_t default_region[RGB_MATRIX_LED_COUNT] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
#endif
